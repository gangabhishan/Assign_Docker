package com.springboot.demo.Assign_Docker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignDockerApplication.class, args);
	}

}
